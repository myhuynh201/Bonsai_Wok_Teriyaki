function insertHello() {
    document.getElementById("demo").innerHTML = "Hello from JS!"
    console.log("Hello to the console!")
  }