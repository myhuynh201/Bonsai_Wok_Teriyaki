function insertHello() {
    $("#demo").text("Hello from jQuery!")
    console.log("Hello to the console!")
  }