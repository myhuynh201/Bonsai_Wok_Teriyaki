Readme.txt

1. Name all student who this submission is for
My Duyen T Huynh, Seungku Kim

2. Write about what you have or haven't implemented

a) Homepage 
- Entry point into the website, we included information about the business
- what food product we sell
- Carousel with special and testimonials are included
- Gave user option to sign in or register. 
*** Extra Feature ***
- breif picture of the food, with popup explanation when hover mouse over
- Contact, Map to the restaurant
- Easy use of buttons to different pages

b) Menu Page
- List the menu item
- List of customization
- Option to Register/sign in
*** Extra Features ***
- Pictures of the food
- explanation of the food
- mobile friendly
- map to the restaurant

c) Order Page
- Allow user to order and select the customization
- display a runnign tally
- user to name specific order (save to favorite)
- reset order
- add order
- user signin/register option
- see previous order/favorite order
*** Extra Features ***
- update price of the order as user click through options
- buttons to cart, add to cart, reset orer, add favorite
- Hide Current, Favorites, Previous order using css

d) Shopping Cart
- Display current order
- breif abbreviated version of the order.
- option to remove the order, edit the order, and mark as favorite
- change quantity of the order, clear the cart, and complete order
- user to sign in or register

e) signin/registration
- valication for sign-in registration, implemented no blanks, email check
- password rules such as at least 1 uppercase, 1 lower case and number
*** Extra Features ***
-used modal so that user does not have to go back and forth.

Food Item Requirements
- 3 different sizes(small medium large)
- 3 different base option (white, brown, fried)
- 8 different protein option 
- 3 specialty option 

Style and Visual Element, easy to follow, matching color schemes.

Code Requiremetns
- Website were strive for ADA compliance.

3. Link to Github repository
https://github.com/myhuynh201/tcss460-a1

4. Link to the home page
https://duyen201-tcss460-a1.herokuapp.com/

